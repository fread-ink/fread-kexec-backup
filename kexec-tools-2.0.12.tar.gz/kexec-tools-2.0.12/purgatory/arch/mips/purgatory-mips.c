#include <purgatory.h>
#include "purgatory-mips.h"

void setup_arch(void)
{
	/* Nothing for now */
}
