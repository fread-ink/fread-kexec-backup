#ifndef PURGATORY_X86_64_H
#define PURGATORY_X86_64_H
#include "../i386/purgatory-x86.h"
#endif /* PURGATORY_X86_64_H */
